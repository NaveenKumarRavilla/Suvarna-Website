import{a as d}from"./index-CAj8YTlX-mw8t6ov4.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=d("Upload",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]]);function h(a){const i=[];let o=[],n="",r=!1;const s=String(a||"").replace(/^\uFEFF/,""),c=s.split(/\r\n|\n|\r/,1)[0]||"",l=(c.match(/\t/g)||[]).length>(c.match(/,/g)||[]).length?"	":",";for(let e=0;e<s.length;e+=1){const t=s[e];r?t==='"'&&s[e+1]==='"'?(n+='"',e+=1):t==='"'?r=!1:n+=t:t==='"'&&n===""?r=!0:t===l?(o.push(n),n=""):t===`
`||t==="\r"?(o.push(n),o.some(p=>p!=="")&&i.push(o),o=[],n="",t==="\r"&&s[e+1]===`
`&&(e+=1)):n+=t}if(r)throw new Error("The CSV file contains an unclosed quoted field.");return o.push(n),o.some(e=>e!=="")&&i.push(o),i}function m(a,i,o){const n=e=>{let t=e==null?"":String(e);return typeof e=="string"&&/^[\t\r ]*[=+\-@]/.test(e)&&(t=`'${t}`),`"${t.replace(/"/g,'""')}"`},r=[i,...o].map(e=>e.map(n).join(",")).join(`\r
`),s=new Blob([`\uFEFF${r}`],{type:"text/csv;charset=utf-8;"}),c=URL.createObjectURL(s),l=document.createElement("a");l.href=c,l.download=a,document.body.appendChild(l),l.click(),l.remove(),window.setTimeout(()=>URL.revokeObjectURL(c),0)}export{u as U,m as d,h as p};
