import{a as c}from"./index-CYY9FWnS-mw7j50o2.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=c("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]),l=async i=>{var n;const e=new TextEncoder().encode(i);if((n=globalThis.crypto)!=null&&n.subtle){const t=await globalThis.crypto.subtle.digest("SHA-256",e);return[...new Uint8Array(t)].map(a=>a.toString(16).padStart(2,"0")).join("")}let o=2166136261,r=2246822519;for(const t of e)o=Math.imul(o^t,16777619),r=Math.imul(r^t,3266489917);return`${e.length}-${(o>>>0).toString(16)}-${(r>>>0).toString(16)}`};export{y as C,l as f};
