import{a as c}from"./index-CYY9FWnS-mw7j50o2.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=c("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{a as C};
